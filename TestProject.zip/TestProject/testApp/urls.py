from django.urls import path
from . import views
from django.conf.urls.static import static
from TestProject import settings

urlpatterns = [
    path('', views.Login,name='login/'),
    path('register', views.Register1),
    path('register/', views.Register),
    path('home/',views.Home),
    path('logout/',views.Logout)

]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
