from django.shortcuts import render, redirect
from .models import User
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view,permission_classes
from rest_framework.permissions import AllowAny
from django.contrib.auth.hashers import make_password, check_password

# Create your views here.

@api_view(['POST','GET'])
@permission_classes([AllowAny, ])
def Login(request):
    try:
        if request.method == 'GET':
            print('login')
            # del request.session['is_active']
            if 'is_active' in request.session:
                return redirect('home/')
            return render(request,'login.html')

        if request.method == 'POST':
            print('post login')
            email = request.POST['email']
            password = request.POST['password']
            
            if User.objects.filter(email=email).exists():
                print('if')
                u = User.objects.get(email=email)
                print(check_password(password,u.password))
                if check_password(password,u.password):
                    print("check if")
                    u.is_active = True
                    u.save()
                    request.session['email'] = u.email
                    request.session['user_id'] = u.id
                    request.session['is_active'] = u.is_active
                    msg = 'Success'
                    return Response(data=msg,status=status.HTTP_200_OK)
                else:
                    return Response(data='Password Wrong',status=status.HTTP_400_BAD_REQUEST)

            else:
                print('else')
                return Response(data='This Email Does Not Exists',status=status.HTTP_400_BAD_REQUEST)
    except Exception as error:
        print('error',error)


@api_view(['POST'])
@permission_classes([AllowAny, ])
def Register(request):
    try:
        print('register',request.data)
        email = request.data['email']
        password = request.data['password']
        fname = request.data['fname']
        lname = request.data['lname']
        image = request.FILES['image']
        print('image---',image)
        print("email",email,password)
        if User.objects.filter(email=email).exists():
            return Response(data='This Email Already Exists',status=status.HTTP_406_NOT_ACCEPTABLE)
        else:
            u = User.objects.create(fname=fname,lname=lname,email=email,password=make_password(password))
            print('u--',u)
            u.image = image
            u.save()
        # return render(request,'login.html',context={'login':True,'register':False})

            return Response(data='Successfully register',status=status.HTTP_200_OK)
    except Exception as error:
        print('error',error)
        return redirect('/')

def Register1(request):
    return render(request,'register.html')


def Logout(request):
    try:
        print('logout')
        email = request.session['email']
        is_active = request.session['is_active']
        user_id = request.session['user_id']
        u = User.objects.filter(email=email)
        if u:
            del request.session['email']
            del request.session['is_active']
            del request.session['user_id']

            uObj = User.objects.get(email=email)
            uObj.is_active = False
            uObj.save()
            return redirect('/')
    except Exception as e:
        print('e',e)
        return redirect('/')

def Home(request):
    print('home')
    try:
        email = request.session['email']
        is_active = request.session['is_active']
        u = User.objects.filter(email=email)
        if u and is_active:
            uObj = User.objects.get(email=email)
            return render(request,'home.html',{'user':uObj})
        else:
            return render(request,'login.html')
    except Exception as e:
        return redirect('/')
